# ArtMod
Mod for game Balatro, improves glass cards and more

# Installation
- Requires [Steamodded](https://github.com/Steamopollys/Steamodded/) version 0.9.5 or higher.
- Requires [Lovely](https://github.com/ethangreen-dev/lovely-injector) version 0.4.0 or higher.
- Download the whole mod as a .zip file, then unzip it in `Appdata/Balatro/Mods`. Make sure the mod is in it's own folder.
- For more information about installing mods, check the [Steamodded readme](https://github.com/Steamopollys/Steamodded?tab=readme-ov-file#how-to-install-a-mod).
- The mod has a config right at the top of the file ArtMod.lua, in case you want to disable something in specific.
